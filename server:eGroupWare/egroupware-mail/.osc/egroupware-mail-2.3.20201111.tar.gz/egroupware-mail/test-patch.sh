#! /bin/sh

#export DEBCONF_DEBUG=developer
set -e
#set -x
  cd $(dirname $0)

  sed -e 's/^#\(services:\)/\1/g' \
      -e 's/^#\(  mail:\)/\1/g' \
      -e 's/^#\(  smtp:\)/\1/g' \
      -e 's/^#\(    extra_hosts:\)/\1/g' \
      -e 's/^#\(      - "db:172.17.0.1"\)/\1/g' \
      -i "" docker-compose.override.yml

  sed -e 's/^#\(networks:\)/\1/g' \
      -e 's/^#\(  egroupwaredocker_default:\)/\1/g' \
      -e 's/^#\(    external: true\)/\1/g' \
      -e 's/^#\(services:\)/\1/g' \
      -e 's/^#\(  mail:\)/\1/g' \
      -e 's/^#\(  smtp:\)/\1/g' \
      -e 's/^#\(    networks:\)/\1/g' \
      -e 's/^#\(      - egroupwaredocker_default\)/\1/g' \
      -i "" docker-compose.override.yml

